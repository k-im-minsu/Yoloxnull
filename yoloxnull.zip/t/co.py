# Load model with pretrained weights
import argparse
from pathlib import Path
import numpy as np
import json
from super_gradients.training import models
from super_gradients.common.object_names import Models
from super_gradients.conversion import ExportTargetBackend
import os
SUPPORTED_YOLO_NAS_TYPE = ["yolo_nas_s", "yolo_nas_m", "yolo_nas_l"]
classes = [$#cl$#]
def parse_opt():
    parser = argparse.ArgumentParser(description="Export Custom Trained YOLO-NAS Model Metadata.")
    required = parser.add_argument_group("required arguments")
    required.add_argument(
        "-m", "--model", type=str, required=True, help="Custom Trained YOLO-NAS checkpoint path"
    )
    required.add_argument(
        "-t", "--type", type=str, required=True, help="Custom Trained YOLO-NAS type model"
    )
    required.add_argument(
        "-n", "--num-classes", type=int, required=True, help="Custom Trained YOLO-NAS num classes"
    )
    parser.add_argument(
        "--export-onnx", type=str, help="Convert model to onnx (path with extension)"
    )

    opt = parser.parse_args()  # parsing args

    opt.model = Path(opt.model)
    opt.type = opt.type.lower()

    # path checking
    if not opt.model.exists():
        raise FileNotFoundError("Wrong path! Model Not Found!")
    if opt.type not in SUPPORTED_YOLO_NAS_TYPE:
        raise NotImplementedError(
            f"Type: {opt.type} isn't supported.\nSupported YOLO-NAS type: {SUPPORTED_YOLO_NAS_TYPE}"
        )
    if opt.export_onnx:
        opt.export_onnx = Path(opt.export_onnx)
        if not opt.export_onnx.parent.exists():
            raise FileNotFoundError("Wrong path! Export directory not found.")

    # logging
    args = vars(opt).items()

    return opt


def get_preprocessing_steps(preprocessing, processing):
    if isinstance(preprocessing, processing.StandardizeImage):
        return {"Standardize": {"max_value": preprocessing.max_value}}
    elif isinstance(preprocessing, processing.DetectionRescale):
        return {"DetRescale": None}
    elif isinstance(preprocessing, processing.DetectionLongestMaxSizeRescale):
        return {"DetLongMaxRescale": None}
    elif isinstance(preprocessing, processing.DetectionBottomRightPadding):
        return {
            "BotRightPad": {
                "pad_value": preprocessing.pad_value,
            }
        }
    elif isinstance(preprocessing, processing.DetectionCenterPadding):
        return {
            "CenterPad": {
                "pad_value": preprocessing.pad_value,
            }
        }
    elif isinstance(preprocessing, processing.NormalizeImage):
        return {
            "Normalize": {"mean": preprocessing.mean.tolist(), "std": preprocessing.std.tolist()}
        }
    elif isinstance(preprocessing, processing.ImagePermute):
        return None
    elif isinstance(preprocessing, processing.ReverseImageChannels):
        return None
    else:
        raise NotImplemented("Model have processing steps that haven't been implemented")
def main():
    from super_gradients.training import models
    import super_gradients.training.processing as processing
    from super_gradients.common.object_names import Models
    subdirs = [name for name in os.listdir('./checkpoints/a')
               if os.path.isfile(os.path.join('./checkpoints/a', name,'ckpt_best.pth'))]
    net = models.get(Models.YOLO_NAS_S, 
        num_classes=len(classes),
        checkpoint_path=os.path.join('./checkpoints/a', subdirs[0],'ckpt_best.pth'))
    dummy = np.random.randint(0, 255, (1000, 800, 3), dtype=np.uint8)

    labels = net._class_names
    iou = net._default_nms_iou
    conf = net._default_nms_conf
    preprocessing_steps = [
        get_preprocessing_steps(st, processing) for st in net._image_processor.processings
    ]
    imgsz = np.expand_dims(net._image_processor.preprocess_image(dummy)[0], 0).shape

    res = {
        "type": Models.YOLO_NAS_S,
        "original_insz": imgsz,
        "iou_thres": iou,
        "score_thres": conf,
        "prep_steps": preprocessing_steps,
        "labels": labels,
    }

    filename = f"$#out$#.json"
    with open(filename, "w") as f:
        f.write(json.dumps(res))
    net.eval()
    net.prep_model_for_conversion(input_size=[1, 3, 640, 640])
    net.export( "$#out$#.onnx",nms_threshold=0.25,confidence_threshold = 0.01,max_predictions_per_image = 100000,num_pre_nms_predictions  = 100000,engine=ExportTargetBackend.ONNXRUNTIME)



if __name__ == "__main__":
    main()

